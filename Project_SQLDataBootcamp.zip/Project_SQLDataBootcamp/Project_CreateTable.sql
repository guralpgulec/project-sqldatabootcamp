CREATE TABLE Categories(
CategoryID INT IDENTITY(1,1),
CategoryName varchar (100)
CONSTRAINT [PK_Categories] PRIMARY KEY CLUSTERED ([CategoryID] ASC))

CREATE TABLE SubCategories(
SubCategoryID INT IDENTITY(1,1),
SubCategoryName varchar (100),
CategoryID int foreign key references Categories
CONSTRAINT [PK_SubCategories] PRIMARY KEY CLUSTERED ([SubCategoryID] ASC))

CREATE TABLE Products(
ProductID INT IDENTITY(1,1),
ProductName varchar (100),
CategoryID int foreign key references Categories,
SubCategoryID int foreign key references SubCategories,
RetailPrice int
CONSTRAINT [PK_Products] PRIMARY KEY CLUSTERED ([ProductID] ASC))


Create TABLE Customers (
CustomerID INT IDENTITY(1,1),
[CompanyName] [nvarchar](40) NOT NULL,
[ContactName] [nvarchar](30) NULL,
[ContactTitle] [nvarchar](30) NULL,
[Address] [nvarchar](60) NULL,
[City] [nvarchar](15) NULL,
[PostalCode] [nvarchar](10) NULL,
[Country] [nvarchar](15) NULL,
[Phone] [nvarchar](24) NULL,
[Fax] [nvarchar](24) NULL, 

CONSTRAINT [PK_Customers] PRIMARY KEY CLUSTERED ([CustomerID] ASC))


CREATE TABLE Orders(
OrderID INT IDENTITY(100,1),
CustomerID int foreign key references Customers,
EmployeeID int foreign key references Employees,
Quantity int,
OrderDate date

CONSTRAINT [PK_Orders] PRIMARY KEY CLUSTERED ([OrderID] ASC))

CREATE TABLE Shipments(
ShipmentID INT IDENTITY(100,1),
OrderID int foreign key references Orders,
OrderDate date,
ShipmentDate date,
ShipmentStatus varchar (50)
CONSTRAINT [PK_Shipments] PRIMARY KEY CLUSTERED ([ShipmentID] ASC))



