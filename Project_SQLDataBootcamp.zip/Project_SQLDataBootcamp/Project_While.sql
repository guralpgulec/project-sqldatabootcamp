declare @counter int = 0
while @counter < 500
begin
    declare @CustomerID int = (select top 1 CustomerID from Customers order by NEWID())
    declare @EmployeeID int = (select top 1 EmployeeID from Employees order by NEWID())
    declare @ProductID int = (select top 1 ProductID from Products order by NEWID())
	declare @Quantity int = (select abs(CONVERT(INT, RAND() * 100))+1)
	DECLARE @mindate DATETIME = '2023-01-01'
    DECLARE @maxdate DATETIME = '2024-05-01'
	declare @OrderDate datetime  = (select(@mindate +(ABS(CAST(CAST( NewID() AS BINARY(8) )AS INT)    ) % CAST((@maxdate - @mindate) AS INT))))
	
 insert into Orders (CustomerID, EmployeeID, Quantity, OrderDate, ProductID, TotalPrice)
 values (@CustomerID , @EmployeeID, @Quantity, @OrderDate, @ProductID, @Quantity * (select RetailPrice from Products where ProductID = @ProductID))

 set @counter = @counter + 1
 end
