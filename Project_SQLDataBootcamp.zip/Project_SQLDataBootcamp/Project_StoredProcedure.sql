create procedure sp_OrdersByDate
	@BeginDate datetime,
	@EndDate datetime
as 
begin
	select c.CompanyName, 
	c.ContactName,
	ct.CategoryName,
	sc.SubCategoryName,
	p.ProductName,
	o.Quantity,
	o.TotalPrice,
	o.OrderDate,
	s.ShipmentDate,
	s.ShipmentStatus
	from Orders o 
	inner join Customers c on o.CustomerID = c.CustomerID
	inner join Products p on o.ProductID = p.ProductID
	inner join Categories ct on p.CategoryID = ct.CategoryID
	inner join SubCategories sc on p.SubCategoryID = sc.SubCategoryID
	inner join Shipments s on o.OrderID = s.OrderID
	where o.OrderDate between @BeginDate and @EndDate
end

exec sp_OrdersByDate
@BeginDate ='2024-01-01',
@EndDate = '2024-01-31'