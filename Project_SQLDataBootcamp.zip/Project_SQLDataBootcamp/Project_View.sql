create view vw_TopSellerProducts as 
select top 10 
	p.ProductName,
	count(OrderID) as TotalNumberOfSales
from Orders o 
inner join Customers c on o.CustomerID = c.CustomerID
inner join Products p on o.ProductID = p.ProductID
group by p.ProductName
order by TotalNumberOfSales desc

select * from vw_TopSellerProducts