create function f_TopNProfitByCompanies (@TopN int)
	returns table 
	as
	return (
		select top (@TopN) c.CompanyName,
		c.Country,
		sum(TotalPrice) as TotalProfit
		from Orders o 
		inner join Customers c on o.CustomerID = c.CustomerID
		inner join Products p on o.ProductID = p.ProductID
		group by c.CompanyName, c.Country
	)

	select * from f_TopNProfitByCompanies (15)